(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_29b7ad52._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_graphql_30d71757._.js",
  "static/chunks/node_modules_date-fns_78d65694._.js",
  "static/chunks/node_modules_recharts_es6_71213595._.js",
  "static/chunks/node_modules_@radix-ui_804c91be._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_@reduxjs_toolkit_b00a18bb._.js",
  "static/chunks/node_modules_2407a48c._.js"
],
    source: "dynamic"
});
