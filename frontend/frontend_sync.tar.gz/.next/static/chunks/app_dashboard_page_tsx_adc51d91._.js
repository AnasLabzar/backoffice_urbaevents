(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_14576f16._.js",
  "static/chunks/node_modules_graphql_30d71757._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_date-fns_de115a49._.js",
  "static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_b0999871._.js",
  "static/chunks/node_modules_react-day-picker_dist_esm_0668ae4e._.js",
  "static/chunks/node_modules_recharts_es6_71213595._.js",
  "static/chunks/node_modules_@radix-ui_c23f804c._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_@reduxjs_toolkit_b00a18bb._.js",
  "static/chunks/node_modules_3fa56ac1._.js"
],
    source: "dynamic"
});
